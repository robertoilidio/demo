﻿/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/

declare function StartSharePointConfigiration(customSharePointUrl: string, clientUrl: string, cc_context: any): void;
