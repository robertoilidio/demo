﻿/**
 * String.format decaration for TypeScript 1.0
 */
interface StringConstructor {
	format(...args: any[]): string;
}
