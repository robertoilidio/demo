﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;
using System.ServiceModel.Description;
using System.Reflection;

// These namespaces are found in the Microsoft.Xrm.Sdk.dll assembly
// located in the SDK\bin folder of the SDK download.
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Discovery;
using Microsoft.Crm.Sdk.Messages;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            IServiceManagement<IOrganizationService> serviceManagement =
            ServiceConfigurationFactory.CreateManagement<IOrganizationService>(
            new Uri("http://serverName/CITTest/XRMServices/2011/Organization.svc"));
                    

            var authCredentials = new AuthenticationCredentials();
            authCredentials.ClientCredentials.Windows.ClientCredential = new System.Net.NetworkCredential("Administrator", "MyPassword");

            using (OrganizationServiceProxy organizationProxy = new OrganizationServiceProxy(serviceManagement, authCredentials.ClientCredentials))
            {

                String subject = "test subject 6";
                String subject2 = "test subject 4";
                String description = "test description 1";

                Entity eEmail = new Entity("email");
                eEmail["subject"] = subject;
                eEmail["description"] = description;
                Guid gEmail = organizationProxy.Create(eEmail);

                Guid queue1ID = new Guid("43515293-be75-e911-8196-000d3a6cbdd3"); /*new Guid("aa5e4666-8343-e911-8190-000d3af9622f"); */
                Guid queue2ID = new Guid("5f8fa29a-be75-e911-8196-000d3a6cbdd3"); /*new Guid("ac5e4666-8343-e911-8190-000d3af9622f"); */

                // Original approach of trying to create two queue items referencing same email

                /*
                    Entity eQueueItem = new Entity("queueitem");
                    eQueueItem["objectid"] = new EntityReference(eEmail.LogicalName, gEmail);
                    eQueueItem["queueid"] = new EntityReference("queue", queue1ID);
                   // organizationProxy.Create(eQueueItem);

                    Entity eQueueItem2 = new Entity("queueitem");
                    eQueueItem2["objectid"] = new EntityReference(eEmail.LogicalName, gEmail);
                    eQueueItem2["queueid"] = new EntityReference("queue", queue2ID);
                   // organizationProxy.Create(eQueueItem2);
                */

                /*------------------------------------APPROACH 1-----------------------------------------------------------------*/

                /* If you want to have the same email (has to be in received state) in two different queues, 
                    1. Add an incoming email (can be ficitious) to the queue based on the queue guid 
                    2. Execute DeliverIncomingEmailRequest to send email to that queue
                */

                EntityReference queue1Ref = new EntityReference("queue", queue1ID);
                EntityReference queue2Ref = new EntityReference("queue", queue2ID);

                String queueEmail = "apple@banana.com";
                String queueEmail2 = "apple2@banana.com";


                Entity queue1 = organizationProxy.Retrieve("queue", queue1ID, new ColumnSet(true));
                //String queueEmail = Guid.NewGuid().ToString() + "@a.com";
                queue1.Attributes["emailaddress"] = queueEmail;
                organizationProxy.Update(queue1);
                Entity queue2 = organizationProxy.Retrieve("queue", queue2ID, new ColumnSet(true));
                queue2.Attributes["emailaddress"] = queueEmail;
                organizationProxy.Update(queue2);

                /*
                if (queue1.Attributes.Contains("emailaddress"))
                {
                    queueEmail1 = (String)queue1.Attributes["emailaddress"];
                }
                else
                {
                    queueEmail1 = Guid.NewGuid().ToString() + "@a.com";
                    queue1.Attributes["emailaddress"] = queueEmail1;
                    organizationProxy.Update(queue1);
                }

                Entity queue2 = organizationProxy.Retrieve("queue", queue2ID, new ColumnSet(true));
                String queueEmail2 = null;
                if (queue2.Attributes.Contains("emailaddress"))
                {
                    queueEmail2 = (String)queue2.Attributes["emailaddress"];
                }
                else
                {
                    queueEmail2 = Guid.NewGuid().ToString() + "@a.com";
                    queue2.Attributes["emailaddress"] = queueEmail2;
                    organizationProxy.Update(queue2);
                }*/

                Microsoft.Xrm.Sdk.EntityCollection attachments = new Microsoft.Xrm.Sdk.EntityCollection();
                attachments.EntityName = "queue"; // attachments is a required parameter in deliverincoming request and entityname is required to be set, set any entity name

                // if there is a valid sender, put it here
                String from;
                if (eEmail.Attributes.Contains("from"))
                {
                    from = (String)eEmail.Attributes["from"];
                }
                else
                {
                    from = Guid.NewGuid().ToString() + "@a.com";
                }

                var deliverEmailRequest = new DeliverIncomingEmailRequest
                {
                    MessageId = Guid.NewGuid().ToString(),
                    Subject = subject,
                    To = queueEmail,
                    From = from,
                    Cc = "cc",
                    Bcc = "",
                    ReceivedOn = DateTime.Now,
                    SubmittedBy = "",
                    Importance = "",
                    Body = description,
                    Attachments = attachments
                };

                organizationProxy.Execute(deliverEmailRequest);
                
                var deliverEmailRequest2 = new DeliverIncomingEmailRequest
                {
                    MessageId = Guid.NewGuid().ToString(),
                    Subject = subject,
                    To = queueEmail,
                    From = from,
                    Cc = "cc2",
                    Bcc = "",
                    ReceivedOn = DateTime.Now,
                    SubmittedBy = "",
                    Importance = "",
                    Body = description,
                    Attachments = attachments
                };

                organizationProxy.Execute(deliverEmailRequest2);
                

                /*------------------------------------APPROACH 2-----------------------------------------------------------------*/

                /* If you want to have the same email (in draft state) in two different queues, this is not supported. 
                    So use the AddToQueue api to add the email in draft state to most recent queue in terms of order of execution
                */
                /*
                var routeRequest = new AddToQueueRequest
                {
                    Target = new EntityReference(eEmail.LogicalName, gEmail),
                    DestinationQueueId = queue1ID
                };
                organizationProxy.Execute(routeRequest);

                var routeRequest2 = new AddToQueueRequest
                {
                    Target = new EntityReference(eEmail.LogicalName, gEmail),
                    DestinationQueueId = queue2ID
                };
                organizationProxy.Execute(routeRequest2);  //will add email to this queue2 and remove from queue1
                */
            }


        }

    }


}
